// TRADE BUNKER server
// npm install && npm start  ->  http://localhost:3000
const path = require('path');
const express = require('express');

const { NFL_RAW, NBA_RAW, SNAPSHOT_DATE } = require('./data/snapshot');
const sleeper = require('./lib/sleeper');
const { newsFor } = require('./lib/news');
const { analyze } = require('./lib/analyst');
const { normName } = require('./lib/util');
const { valueOf } = require('./public/values');

const PORT = process.env.PORT || 3000;
const app = express();
app.use(express.json({ limit: '200kb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ---------- snapshot -> objects ---------- */
const SNAP = {
  NFL: NFL_RAW.map(r => ({
    sport: 'NFL', name: r[0], pos: r[1], team: r[2], rank: r[3], ppg: r[4], gp: r[5], last: r[6],
    trend: r[7], status: r[8], note: String(r[9] || '').trim(), estRank: r[10] || null, source: 'snapshot'
  })),
  NBA: NBA_RAW.map(r => ({
    sport: 'NBA', name: r[0], pos: '', team: r[1], rank: r[2], stats: r[3], trend: r[4], status: r[5],
    note: String(r[6] || '').trim(), estRank: r[7] || null, source: 'snapshot'
  }))
};

const live = {
  NFL: { ok: false, error: null, at: null, week: null, season: null, stats: false },
  NBA: { ok: false, error: null, at: null }
};

/* ---------- merge snapshot with live Sleeper data ---------- */
async function buildPlayers(sport) {
  const base = SNAP[sport].map(p => ({ ...p }));
  let sl = null, stats = null, hot = new Map();
  try {
    sl = await sleeper.players(sport);
    live[sport].ok = true; live[sport].error = null; live[sport].at = new Date().toISOString();
  } catch (e) {
    live[sport].ok = false; live[sport].error = e.message;
  }
  if (sport === 'NFL' && sl) {
    try {
      const st = await sleeper.nflState();
      live.NFL.week = st.week; live.NFL.season = st.season;
      stats = await sleeper.nflSeasonStats(st.season);
      live.NFL.stats = stats.size > 0;
    } catch (e) { live.NFL.stats = false; }
  }
  if (sl) {
    try {
      const tr = await sleeper.trending(sport, 'add');
      tr.forEach((t, i) => hot.set(String(t.player_id), { count: t.count, rank: i + 1 }));
    } catch (e) { /* trending is optional */ }
  }

  const seen = new Set();
  for (const p of base) {
    if (p.pos === 'DST') {
      // Sleeper keys team defenses by team abbreviation.
      if (stats && stats.has(p.team)) {
        const st = stats.get(p.team);
        p.livePPR = st.ppr != null ? +(st.ppr / st.gp).toFixed(1) : null;
        p.liveHalf = st.half != null ? +(st.half / st.gp).toFixed(1) : p.livePPR;
        p.liveGP = st.gp;
      }
      continue;
    }
    const key = normName(p.name);
    seen.add(key);
    const s = sl && sl.byName.get(key);
    if (!s) continue;
    p.sleeperId = s.id;
    if (sport === 'NBA') p.pos = s.pos;
    if (s.team && s.team !== 'FA' && s.team !== p.team && p.team !== '—') p.teamLive = s.team;
    if (p.team === '—' && s.team) p.team = s.team;
    // Live injury status overrides the snapshot.
    if (s.injury !== p.status) {
      if (s.injury) p.liveNote = `LIVE: ${s.injury}${s.injuryNote ? ' (' + s.injuryNote + ')' : ''}`;
      else if (p.status) p.liveNote = 'LIVE: no injury designation on Sleeper right now.';
      p.status = s.injury;
    }
    if (stats && stats.has(s.id)) {
      const st = stats.get(s.id);
      p.livePPR = st.ppr != null ? +(st.ppr / st.gp).toFixed(1) : null;
      p.liveHalf = st.half != null ? +(st.half / st.gp).toFixed(1) : null;
      p.liveGP = st.gp;
    }
    const h = hot.get(s.id);
    if (h) p.hot = h;
  }

  // Add every other fantasy-relevant player from Sleeper, valued by search rank.
  if (sl) {
    const cap = sport === 'NFL' ? 400 : 320;
    for (const s of sl.byName.values()) {
      const key = normName(s.name);
      if (seen.has(key)) continue;
      if (s.searchRank == null || s.searchRank > cap) continue;
      if (!s.team || s.team === 'FA') continue;
      const p = {
        sport, name: s.name, pos: s.pos, team: s.team, rank: null, estRank: null, sleeperRank: s.searchRank,
        trend: 0, status: s.injury, note: s.injury ? `LIVE: ${s.injury}${s.injuryNote ? ' (' + s.injuryNote + ')' : ''}` : '',
        source: 'sleeper', sleeperId: s.id, est: true
      };
      if (stats && stats.has(s.id)) {
        const st = stats.get(s.id);
        p.livePPR = st.ppr != null ? +(st.ppr / st.gp).toFixed(1) : null;
        p.liveHalf = st.half != null ? +(st.half / st.gp).toFixed(1) : null;
        p.liveGP = st.gp;
      }
      const h = hot.get(s.id);
      if (h) p.hot = h;
      base.push(p);
    }
  }
  base.forEach(p => { if (p.rank == null) p.est = true; });
  return base;
}

const playerCache = new Map();
const building = new Map();
async function getPlayers(sport) {
  const hit = playerCache.get(sport);
  if (hit && Date.now() - hit.t < 30 * 60 * 1000) return hit.v;
  if (building.has(sport)) return hit ? hit.v : building.get(sport);
  const job = buildPlayers(sport)
    // If the live feed failed, retry in ~2 minutes instead of 30.
    .then(v => { playerCache.set(sport, { v, t: live[sport].ok ? Date.now() : Date.now() - 28 * 60 * 1000 }); return v; })
    .finally(() => building.delete(sport));
  building.set(sport, job);
  return hit ? hit.v : job;
}

/* ---------- API ---------- */
const sportOf = q => (String(q || '').toUpperCase() === 'NBA' ? 'NBA' : 'NFL');

app.get('/api/status', (req, res) => {
  res.json({ snapshot: SNAPSHOT_DATE, live, aiEngine: process.env.ANTHROPIC_API_KEY ? 'claude-api' : 'local' });
});

app.get('/api/players', async (req, res) => {
  const sport = sportOf(req.query.sport);
  // Don't make the page wait on a cold Sleeper download: answer with the snapshot
  // after 4 seconds and let the client poll again.
  const fallback = () => SNAP[sport].map(p => ({ ...p, est: p.rank == null }));
  try {
    const players = await Promise.race([getPlayers(sport), new Promise(r => setTimeout(() => r(null), 4000))]);
    if (!players) return res.json({ sport, snapshot: SNAPSHOT_DATE, live: { ...live[sport], pending: true }, players: fallback() });
    res.json({ sport, snapshot: SNAPSHOT_DATE, live: live[sport], players });
  } catch (e) {
    res.json({ sport, snapshot: SNAPSHOT_DATE, live: live[sport], players: fallback() });
  }
});

app.get('/api/news', async (req, res) => {
  const name = String(req.query.name || '').slice(0, 80).trim();
  if (!name) return res.status(400).json({ error: 'name required' });
  try {
    res.json(await newsFor(name, sportOf(req.query.sport)));
  } catch (e) {
    res.json({ name, items: [], sentiment: 0, error: 'News feed unreachable right now.' });
  }
});

app.post('/api/analyze', async (req, res) => {
  const b = req.body || {};
  const sport = sportOf(b.sport);
  const settings = b.settings || {};
  const clean = list => (Array.isArray(list) ? list.slice(0, 7) : []).map(p => ({
    sport, name: String(p.name || '').slice(0, 80), pos: p.pos || '', team: p.team || '', rank: p.rank ?? null,
    estRank: p.estRank ?? null, sleeperRank: p.sleeperRank ?? null, status: p.status || '', trend: +p.trend || 0,
    ppg: p.ppg ?? null, note: String(p.note || '').slice(0, 400), custom: !!p.custom, customVal: +p.customVal || 25,
    est: !!p.est, rankLabel: p.rankLabel || '', stats: p.stats || null
  }));
  const give = clean(b.give), get = clean(b.get);
  if (!give.length || !get.length) return res.status(400).json({ error: 'Need players on both sides.' });
  for (const p of [...give, ...get]) p.value = valueOf(p, settings);

  // Pull live news for everyone in the deal (in parallel, failures ignored).
  await Promise.all([...give, ...get].map(async p => {
    try { p.news = await newsFor(p.name, sport); } catch { p.news = { items: [], sentiment: 0 }; }
  }));

  let pool = [];
  try { pool = (await getPlayers(sport)).map(p => ({ name: p.name, status: p.status, value: valueOf(p, settings) })); } catch {}

  const input = { sport, mode: b.mode, risk: b.risk, needs: String(b.needs || '').slice(0, 600), context: String(b.context || '').slice(0, 600), give, get, pool };

  if (process.env.ANTHROPIC_API_KEY) {
    try {
      const out = await claudeVerdict(input, settings);
      return res.json({ ...out, engine: 'claude-api', news: newsPayload(give, get) });
    } catch (e) {
      console.warn('Claude API failed, falling back to local engine:', e.message);
    }
  }
  res.json({ ...analyze(input), news: newsPayload(give, get) });
});

function newsPayload(give, get) {
  return Object.fromEntries([...give, ...get].map(p => [p.name, p.news]));
}

/* ---------- optional: Claude API (billed to your API key, not your Claude.ai plan) ---------- */
async function claudeVerdict(input, settings) {
  const brief = p => ({
    name: p.name, pos: p.pos, team: p.team, value: p.value, rank: p.rankLabel, status: p.status || 'healthy',
    trend: p.trend, ppg: p.ppg, note: p.note, headlines: (p.news?.items || []).slice(0, 4).map(i => i.title)
  });
  const prompt = `You are a blunt fantasy ${input.sport === 'NFL' ? 'football' : 'basketball'} trade analyst. League: ${JSON.stringify(settings)}. Team mode: ${input.mode}. Risk: ${input.risk}. Roster notes: ${input.needs || 'none'}. Extra context from the user (take it seriously): ${input.context || 'none'}.
USER GIVES: ${JSON.stringify(input.give.map(brief))}
USER GETS: ${JSON.stringify(input.get.map(brief))}
Use only these facts plus general knowledge. Reply with ONLY JSON: {"verdict":"SMASH ACCEPT|ACCEPT|LEAN ACCEPT|COIN FLIP|LEAN DECLINE|DECLINE|HARD PASS","grade":"A+..F","confidence":0-100,"headline":"","summary":"3-4 sentences","reasons_for":[],"reasons_against":[],"risks":[],"player_takes":[{"name":"","side":"give|get","outlook":"BUY|SELL|HOLD","take":""}],"counter_offer":""}`;
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 1500, messages: [{ role: 'user', content: prompt }] })
  });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const j = await r.json();
  const text = (j.content || []).map(c => c.text || '').join('');
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) throw new Error('No JSON in reply');
  return JSON.parse(m[0]);
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  TRADE BUNKER is live on http://localhost:${PORT}`);
  console.log(`  Verdict engine: ${process.env.ANTHROPIC_API_KEY ? 'Claude API (your API key)' : 'built-in Bunker Brain (free, offline)'}`);
  console.log('  Warming up live Sleeper data in the background...\n');
  getPlayers('NFL').then(p => console.log(`  NFL ready: ${p.length} players (live: ${live.NFL.ok})`)).catch(() => {});
  getPlayers('NBA').then(p => console.log(`  NBA ready: ${p.length} players (live: ${live.NBA.ok})`)).catch(() => {});
});
