# TRADE BUNKER

A fantasy trade calculator for NFL and NBA. It shows live injury status, live NFL stats, live news headlines, player values, and a built-in trade analyst that rules on every deal.

**It needs no API keys and uses none of your Claude usage.** All of it runs on your own server.

## Run it in GitHub Codespaces

```bash
cd fantasytrade
npm install
npm start
```

Codespaces shows a popup saying "Your application running on port 3000 is available". Click **Open in Browser**. If you miss the popup, open the **Ports** tab next to the terminal and click the globe icon on port 3000.

It runs the same way on your own computer (Node 18 or newer); then go to http://localhost:3000.

`npm run dev` restarts the server automatically whenever you edit a file.

## What's live and what's a snapshot

| Data | Source | Refresh |
|---|---|---|
| Injury status (Q / OUT / IR) | [Sleeper API](https://docs.sleeper.com) (free, no key) | every 6 hours |
| NFL PPR and half-PPR points per game | Sleeper season stats | every 3 hours |
| Trending adds (🔥) | Sleeper trending | every hour |
| Full player pool (any active player) | Sleeper | every 6 hours |
| News headlines + sentiment | Google News RSS, last 7 days | every 20 minutes |
| Rest-of-season ranks, notes, NBA stat lines | Researched snapshot in `data/snapshot.js` (Nov 6, 2026) | edit the file |

Players who aren't in the snapshot are valued from Sleeper's overall rank and tagged **EST**. If Sleeper or Google News can't be reached, the app falls back to the snapshot and keeps working.

## How the verdict works ("Bunker Brain")

`lib/analyst.js` is a rule-based engine. It weighs:

- **Value.** Each player's value (0–100) comes from his rest-of-season positional rank, run through a decay curve (`public/values.js`). Superflex boosts QBs ×1.75 and half-PPR trims WR/TE 5%.
- **Roster adjustment.** Your best piece counts in full and each extra piece counts for less (100/80/65/52/42%), so one stud beats two mid-tier players.
- **Injuries.** IR and OUT players lose value. The penalty is bigger if you're contending and smaller if you're rebuilding.
- **Trends.** Rising and falling stock, plus Sleeper trending adds.
- **Live news sentiment.** The engine scores headlines by keyword ("torn", "ruled out", "surgery" count against a player; "career-high", "cleared", "lead back" count for him).
- **Your settings.** Team mode, risk appetite, and the positions your roster notes say you need.

It returns a verdict, a letter grade, a confidence level, reasons for and against, a watch list, a take on each player, and a counter-offer.

### Optional: use Claude through the API instead

To swap in Claude's written analysis, set an Anthropic API key before starting. API usage is billed per request to your Anthropic Console account. It's separate from your Claude.ai plan and doesn't touch its limits.

```bash
export ANTHROPIC_API_KEY=sk-ant-...
npm start
```

If the API call fails, the app falls back to the built-in engine.

## Updating the snapshot

Edit `data/snapshot.js`. Each NFL row is:

```
[name, pos, team, rosPosRank, ppg, gamesPlayed, week8Pts, trend(1/0/-1), status("", "Q", "OUT", "IR"), note, estRank]
```

Each NBA row is:

```
[name, team, rosRank, {stat: value}, trend, status, note, estRank]
```

## Files

```
fantasytrade/
├─ server.js          Express server + API routes
├─ package.json
├─ data/snapshot.js   researched rankings + notes
├─ lib/sleeper.js     live Sleeper data (players, injuries, stats, trending)
├─ lib/news.js        Google News RSS + headline sentiment
├─ lib/analyst.js     the trade verdict engine
├─ lib/util.js        caching, fetch, name matching
└─ public/            the website (index.html, style.css, app.js, values.js)
```

## API

- `GET /api/players?sport=NFL|NBA`: merged snapshot + live player pool
- `GET /api/news?sport=NFL&name=Josh%20Allen`: latest headlines with sentiment
- `POST /api/analyze`: trade verdict. Body: `{ sport, settings, mode, risk, needs, give: [...], get: [...] }`
- `GET /api/status`: live-feed health

## Snapshot sources (Nov 6, 2026)

- ESPN rest-of-season rankings (Nov 3)
- FFBeacon PPR leaders (through Week 8)
- FantasyCalc risers and fallers
- RotoWire and Yahoo Week 9 injury reports
- FantraxHQ NBA rest-of-season rankings (November)
- RotoWire NBA buy-low/sell-high and Week 3 trends
- FantraxHQ NBA trade market
