// Shared value model, used by both the browser and the server.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TBValues = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  // Positional decay curves for NFL rest-of-season positional ranks: [value at #1, decay per rank].
  const POS_CURVE = { RB: [100, 0.952], WR: [98, 0.954], TE: [72, 0.90], QB: [64, 0.94], DST: [20, 0.92] };
  const WEIGHTS = [1, 0.8, 0.65, 0.52, 0.42, 0.35, 0.3];

  function nflBase(pos, rank) {
    const c = POS_CURVE[pos] || [60, 0.95];
    return c[0] * Math.pow(c[1], rank - 1);
  }
  function nbaBase(rank) { return 100 * Math.pow(0.972, rank - 1); }
  // Players only known from Sleeper: estimate from Sleeper's overall search rank.
  function fromSearchRank(sr, sport) {
    return (sport === 'NFL' ? 88 : 90) * Math.pow(sport === 'NFL' ? 0.978 : 0.975, Math.max(0, sr - 1));
  }

  function valueOf(p, settings) {
    settings = settings || {};
    if (p.custom) return p.customVal || 25;
    let v;
    if (p.sport === 'NFL') {
      if (p.rank != null || p.estRank != null) v = nflBase(p.pos, p.rank ?? p.estRank);
      else if (p.sleeperRank != null) v = fromSearchRank(p.sleeperRank, 'NFL');
      else v = 3;
      if (p.pos === 'QB' && settings.fmt === 'SF') v *= 1.75;
      if (settings.score === 'HALF' && (p.pos === 'WR' || p.pos === 'TE')) v *= 0.95;
      if (p.status === 'OUT' && p.rank == null && p.seasonOver) v = Math.min(v, 1);
    } else {
      if (p.rank != null || p.estRank != null) v = nbaBase(p.rank ?? p.estRank);
      else if (p.sleeperRank != null) v = fromSearchRank(p.sleeperRank, 'NBA');
      else v = 3;
    }
    // Small league-size nudge: deeper leagues make mid-tier players worth relatively more.
    const teams = +settings.teams || 12;
    if (teams !== 12) v = v * (1 + (teams - 12) * 0.012 * (v < 40 ? 1 : -0.5));
    return Math.max(1, Math.round(v * 10) / 10);
  }

  function adjTotal(vals) {
    return [...vals].sort((a, b) => b - a).reduce((s, v, i) => s + v * (WEIGHTS[i] ?? 0.25), 0);
  }

  return { valueOf, adjTotal, WEIGHTS };
});
