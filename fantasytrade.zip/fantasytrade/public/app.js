/* TRADE BUNKER client */
const { valueOf: modelValue, adjTotal: modelAdj } = window.TBValues;

const S = { sport: 'NFL', fmt: '1QB', score: 'PPR', give: [], get: [], bbPos: 'ALL', bbSort: 'val', bbDir: -1, pools: {}, live: {}, busy: false };
try { const s = localStorage.getItem('tb_sport'); if (s === 'NBA' || s === 'NFL') S.sport = s; } catch (e) {}

const $ = id => document.getElementById(id);
const settings = () => ({ fmt: S.fmt, score: S.score, teams: +$('teams').value });
const valueOf = p => modelValue(p, settings());
const adjTotal = list => modelAdj(list.map(valueOf));
const rawTotal = list => list.reduce((s, p) => s + valueOf(p), 0);
const pool = () => S.pools[S.sport] || [];
const norm = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, '');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const titleCase = s => s.replace(/\b\w/g, c => c.toUpperCase());

function ppgOf(p) {
  if (p.sport !== 'NFL') return null;
  const live = S.score === 'HALF' ? p.liveHalf : p.livePPR;
  if (live != null) return { v: live, gp: p.liveGP, live: true };
  if (p.ppg != null) return { v: p.ppg, gp: p.gp, live: false };
  return null;
}
function rankLabel(p) {
  if (p.custom) return 'CUSTOM';
  if (p.sport === 'NFL') return p.rank ? `${p.pos === 'DST' ? 'D/ST' : p.pos}${p.rank} ROS` : p.sleeperRank ? `${p.pos} · SLP #${p.sleeperRank}` : `${p.pos} · NR`;
  return p.rank ? `#${p.rank} ROS` : p.sleeperRank ? `SLP #${p.sleeperRank}` : 'NR';
}


/* ---------- team logos + colors ---------- */
const TEAM_COLORS = {
  NFL: { ARI:'#97233F', ATL:'#A71930', BAL:'#241773', BUF:'#00338D', CAR:'#0085CA', CHI:'#0B162A', CIN:'#FB4F14', CLE:'#311D00', DAL:'#041E42', DEN:'#FB4F14',
    DET:'#0076B6', GB:'#203731', HOU:'#03202F', IND:'#002C5F', JAX:'#006778', KC:'#E31837', LV:'#000000', LAC:'#0080C6', LAR:'#003594', MIA:'#008E97',
    MIN:'#4F2683', NE:'#002244', NO:'#9F8958', NYG:'#0B2265', NYJ:'#125740', PHI:'#004C54', PIT:'#101820', SF:'#AA0000', SEA:'#002244', TB:'#D50A0A',
    TEN:'#0C2340', WAS:'#5A1414' },
  NBA: { ATL:'#E03A3E', BOS:'#007A33', BKN:'#000000', CHA:'#1D1160', CHI:'#CE1141', CLE:'#860038', DAL:'#00538C', DEN:'#0E2240', DET:'#C8102E', GSW:'#1D428A',
    HOU:'#CE1141', IND:'#002D62', LAC:'#C8102E', LAL:'#552583', MEM:'#5D76A9', MIA:'#98002E', MIL:'#00471B', MIN:'#0C2340', NOR:'#0C2340', NOP:'#0C2340',
    NYK:'#F58426', OKC:'#007AC1', ORL:'#0077C0', PHI:'#006BB6', PHO:'#1D1160', PHX:'#1D1160', POR:'#E03A3E', SAC:'#5A2D81', SAS:'#C4CED4', TOR:'#CE1141',
    UTA:'#002B5C', UTH:'#002B5C', WAS:'#002B5C' }
};
const ESPN_ABBR = {
  NFL: { WAS: 'wsh' },
  NBA: { SAS:'sa', GSW:'gs', NYK:'ny', NOR:'no', NOP:'no', UTA:'utah', UTH:'utah', PHO:'phx', WAS:'wsh' }
};
const SLEEPER_ABBR = { NBA: { NOR:'nop', UTH:'uta', PHO:'phx', GSW:'gsw' } };
function teamCode(p) { return String(p.teamLive || p.team || '').toUpperCase(); }
function logoSrcs(sport, team) {
  if (!team || team === '?' || team === '—' || team === 'FA') return [];
  const sp = sport.toLowerCase();
  const e = (ESPN_ABBR[sport] && ESPN_ABBR[sport][team]) || team.toLowerCase();
  const sl = (SLEEPER_ABBR[sport] && SLEEPER_ABBR[sport][team]) || team.toLowerCase();
  return [`https://a.espncdn.com/i/teamlogos/${sp}/500/${e}.png`, `https://sleepercdn.com/images/team_logos/${sp}/${sl}.png`];
}
// Try ESPN, then Sleeper, then fall back to the team's letters.
window.tbLogoErr = img => {
  const alt = img.dataset.alt;
  if (alt) { img.dataset.alt = ''; img.src = alt; return; }
  const span = document.createElement('span');
  span.className = 'team-txt'; span.textContent = img.dataset.team || '';
  if (img.classList.contains('tlogo-sm')) img.replaceWith(span); else img.remove();
};
function logoImg(p, cls = 'tlogo') {
  const team = teamCode(p);
  const [a, b] = logoSrcs(p.sport, team);
  if (!a) return cls === 'tlogo-sm' ? `<span class="team-txt">${esc(team || '—')}</span>` : '';
  return `<img class="${cls}" src="${a}" data-alt="${b}" data-team="${esc(team)}" alt="${esc(team)}" loading="lazy" referrerpolicy="no-referrer" onerror="tbLogoErr(this)">`;
}
function initials(name) {
  const parts = String(name).replace(/\b(Jr|Sr|II|III|IV)\.?$/i, '').trim().split(/\s+/);
  return ((parts[0] || '')[0] || '') + ((parts[parts.length - 1] || '')[0] || '');
}
function avatarHTML(p) {
  if (p.pos === 'DST') return `<div class="avatar-wrap dst">${logoImg(p) || `<span class="team-txt">${esc(teamCode(p))}</span>`}</div>`;
  const col = (TEAM_COLORS[p.sport] || {})[teamCode(p)] || '#5a4a38';
  return `<div class="avatar-wrap"><div class="avatar" style="background:linear-gradient(135deg, ${col}, #111 140%)">${esc(initials(p.name).toUpperCase())}</div>${logoImg(p)}</div>`;
}

/* ---------- data loading ---------- */
async function loadPool(sport, force) {
  if (S.pools[sport] && !force) return;
  // The server answers with the snapshot while live data warms up; poll until it's live.
  try {
    const r = await fetch(`/api/players?sport=${sport}`);
    const j = await r.json();
    S.pools[sport] = j.players;
    S.live[sport] = j.live;
    if (j.live && j.live.pending) setTimeout(() => loadPool(sport, true), 5000);
  } catch (e) {
    if (!S.pools[sport]) S.pools[sport] = [];
    S.live[sport] = { ok: false, error: 'Server unreachable' };
  }
  // Keep cards in the trade up to date with live status.
  for (const side of ['give', 'get']) {
    S[side] = S[side].map(p => {
      if (p.custom || p.sport !== sport) return p;
      const fresh = S.pools[sport].find(x => x.name === p.name);
      return fresh ? { ...fresh, news: p.news } : p;
    });
  }
  if (sport === S.sport) renderAll();
}
function renderLive() {
  const L = S.live[S.sport];
  const dot = $('liveDot'), txt = $('liveText');
  if (!L) { dot.className = 'live-dot'; txt.textContent = 'Connecting to live data…'; return; }
  if (L.pending) { dot.className = 'live-dot'; txt.innerHTML = 'Snapshot loaded · <span style="color:var(--amber)">downloading live Sleeper data…</span>'; return; }
  dot.className = 'live-dot' + (L.ok ? ' on' : '');
  if (L.ok) {
    txt.innerHTML = S.sport === 'NFL'
      ? `<b>LIVE</b> · Sleeper${L.season ? ` · ${esc(L.season)} Wk ${esc(L.week)}` : ''}${L.stats ? ' · stats on' : ''} · ${pool().length} players`
      : `<b>LIVE</b> · Sleeper injuries · ${pool().length} players`;
  } else {
    txt.innerHTML = `Snapshot mode (Nov 6, 2026) · <span style="color:var(--amber)">live feed offline</span>`;
  }
}

/* ---------- segments ---------- */
function bindSeg(id, key, cb) {
  $(id).addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    S[key] = b.dataset.v;
    [...$(id).children].forEach(x => x.classList.toggle('on', x === b));
    cb && cb();
  });
}
const setSegOn = (id, v) => [...$(id).children].forEach(x => x.classList.toggle('on', x.dataset.v === v));
bindSeg('sportSeg', 'sport', () => {
  S.give = []; S.get = []; S.bbPos = 'ALL'; hideReport();
  try { localStorage.setItem('tb_sport', S.sport); } catch (e) {}
  renderAll(); loadPool(S.sport);
});
bindSeg('fmtSeg', 'fmt', renderAll);
bindSeg('scoreSeg', 'score', renderAll);
$('teams').addEventListener('change', renderAll);

/* ---------- search ---------- */
function setupSearch(side) {
  const input = $(side + 'In'), dd = $(side + 'Dd');
  let act = 0, items = [];
  const close = () => dd.classList.remove('show');
  function render() {
    const q = norm(input.value.trim());
    if (!q) { close(); return; }
    const taken = new Set([...S.give, ...S.get].map(p => p.name));
    items = pool().filter(p => !taken.has(p.name) && norm(p.name).includes(q))
      .sort((a, b) => {
        const as = norm(a.name).startsWith(q) ? 0 : 1, bs = norm(b.name).startsWith(q) ? 0 : 1;
        return as - bs || valueOf(b) - valueOf(a);
      }).slice(0, 8);
    let html = items.map((p, i) => `<div class="opt ${i === act ? 'act' : ''}" data-i="${i}"><span>${logoImg(p, 'tlogo-sm')}${esc(p.name)} <small>${esc(p.pos || '')}${p.pos ? ' · ' : ''}${esc(p.team)}${p.status ? ' · ' + p.status : ''}${p.est ? ' · est' : ''}</small></span><span class="v">${valueOf(p).toFixed(0)}</span></div>`).join('');
    html += `<div class="opt custom ${act === items.length ? 'act' : ''}" data-i="custom"><span>+ Add “${esc(input.value.trim())}” as custom player</span><small>set value by hand</small></div>`;
    dd.innerHTML = html; dd.classList.add('show');
  }
  function pick(i) {
    if (i === 'custom' || i === items.length) {
      const nm = input.value.trim(); if (!nm) return;
      const isDef = S.sport === 'NFL' && /\b(d\/?st|defen[cs]e|def)\b/i.test(nm);
      addPlayer(side, { sport: S.sport, name: titleCase(nm), pos: isDef ? 'DST' : S.sport === 'NFL' ? 'FLEX' : '', team: '?', custom: true, customVal: 25, trend: 0, status: '', note: 'Not in the player pool. Set his value with the slider.' });
    } else addPlayer(side, items[i]);
    input.value = ''; act = 0; close();
  }
  input.addEventListener('input', () => { act = 0; render(); });
  input.addEventListener('focus', render);
  input.addEventListener('keydown', e => {
    if (!dd.classList.contains('show')) return;
    if (e.key === 'ArrowDown') { act = Math.min(items.length, act + 1); render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { act = Math.max(0, act - 1); render(); e.preventDefault(); }
    else if (e.key === 'Enter') { pick(act); e.preventDefault(); }
    else if (e.key === 'Escape') close();
  });
  dd.addEventListener('mousedown', e => {
    const o = e.target.closest('.opt'); if (!o) return;
    e.preventDefault(); pick(o.dataset.i === 'custom' ? 'custom' : +o.dataset.i);
  });
  document.addEventListener('click', e => { if (!e.target.closest('#' + side + 'In') && !e.target.closest('#' + side + 'Dd')) close(); });
}
setupSearch('give'); setupSearch('get');

/* ---------- news ---------- */
const newsCache = new Map();
async function loadNews(p) {
  if (p.custom || p.news !== undefined) return;
  const key = S.sport + ':' + p.name;
  p.news = null; // loading
  try {
    if (!newsCache.has(key)) newsCache.set(key, fetch(`/api/news?sport=${S.sport}&name=${encodeURIComponent(p.name)}`).then(r => r.json()));
    p.news = await newsCache.get(key);
  } catch (e) { p.news = { items: [], sentiment: 0, error: 'News unavailable' }; }
  renderSide('give'); renderSide('get');
}
function newsHTML(p) {
  if (p.custom) return '';
  if (p.news === null || p.news === undefined) return `<div class="news"><div class="nh"><span>Live headlines</span><span>scanning…</span></div></div>`;
  const n = p.news;
  if (!n.items || !n.items.length) return `<div class="news"><div class="nh"><span>Live headlines</span><span>${n.error ? esc(n.error) : 'nothing in the last 7 days'}</span></div></div>`;
  const s = n.sentiment || 0;
  const cls = s >= 0.6 ? 's-pos' : s <= -0.6 ? 's-neg' : 's-neu';
  const lbl = s >= 0.6 ? 'POSITIVE' : s <= -0.6 ? 'NEGATIVE' : 'NEUTRAL';
  const ago = d => { const t = Date.parse(d); if (!t) return ''; const h = Math.round((Date.now() - t) / 36e5); return h < 1 ? 'now' : h < 48 ? h + 'h' : Math.round(h / 24) + 'd'; };
  return `<div class="news"><div class="nh"><span>Live headlines · 7 days</span><span class="badge ${cls}">${lbl} ${s > 0 ? '+' : ''}${s.toFixed(1)}</span></div>
    ${n.items.slice(0, 3).map(i => `<a href="${esc(i.link)}" target="_blank" rel="noopener">${i.score > 0 ? '▲ ' : i.score < 0 ? '▼ ' : '· '}${esc(i.title)}<small>${esc(i.source || '')} ${ago(i.date)}</small></a>`).join('')}</div>`;
}

/* ---------- cards ---------- */
function addPlayer(side, p) {
  if (S[side].length >= 7) return;
  if ([...S.give, ...S.get].some(x => x.name === p.name)) return;
  const c = { ...p };
  S[side].push(c); renderAll(); loadNews(c);
}
function removePlayer(side, name) { S[side] = S[side].filter(p => p.name !== name); renderAll(); }

function statChips(p) {
  if (p.custom) return '';
  const out = [];
  if (p.sport === 'NFL') {
    const g = ppgOf(p);
    if (g) {
      out.push(`<span class="stat"><i>${S.score === 'HALF' && g.live ? 'Half PPG' : 'PPG'}</i><b>${g.v.toFixed(1)}</b>${g.live ? ' <i style="color:var(--green)">live</i>' : ''}</span>`);
      if (g.gp) out.push(`<span class="stat"><i>GP</i><b>${g.gp}</b></span>`);
      if (g.gp) out.push(`<span class="stat"><i>Total</i><b>${(g.v * g.gp).toFixed(0)}</b></span>`);
    }
    if (p.last != null) out.push(`<span class="stat"><i>Wk8</i><b>${p.last.toFixed(1)}</b></span>`);
    if (!out.length) out.push(`<span class="stat"><i>Stats</i><b style="color:var(--muted)">not available</b></span>`);
  } else {
    if (p.stats) for (const [k, v] of Object.entries(p.stats)) out.push(`<span class="stat"><i>${esc(k)}</i><b>${esc(v)}</b></span>`);
    else out.push(`<span class="stat"><i>Stats</i><b style="color:var(--muted)">rank only</b></span>`);
  }
  return `<div class="pc-stats">${out.join('')}</div>`;
}
function badges(p) {
  let b = '';
  if (p.status) b += `<span class="badge b-${p.status}">${p.status}</span>`;
  if (p.hot) b += `<span class="badge b-up">🔥 #${p.hot.rank} ADD</span>`;
  if (p.trend === 1) b += `<span class="badge b-up">▲ RISING</span>`;
  if (p.trend === -1) b += `<span class="badge b-down">▼ FALLING</span>`;
  if (!p.custom && p.rank == null) b += `<span class="badge b-est">EST</span>`;
  if (p.custom) b += `<span class="badge b-custom">CUSTOM</span>`;
  return b;
}
function cardHTML(side, p) {
  const note = [p.liveNote, p.note].filter(Boolean).join(' ');
  return `<div class="pcard st-${p.status || 'ok'}">
    <button class="pc-x" data-side="${side}" data-name="${esc(p.name)}" title="Remove">✕</button>
    <div class="pc-top">
      <div class="pc-id">
        ${avatarHTML(p)}
        <div>
          <div class="pc-name">${esc(p.name)}</div>
          <div class="pc-meta">${p.pos && p.pos !== 'DST' ? esc(p.pos) + ' · ' : ''}${esc(p.teamLive || p.team)} · ${rankLabel(p)} ${badges(p)}</div>
        </div>
      </div>
      <div class="pc-val"><div class="n">${valueOf(p).toFixed(0)}</div><div class="s">value</div></div>
    </div>
    ${statChips(p)}
    ${note ? `<div class="pc-note">${esc(note)}</div>` : ''}
    ${p.custom ? `<div class="pc-slider">VALUE <input type="range" min="1" max="100" value="${p.customVal}" data-side="${side}" data-name="${esc(p.name)}"> <span>${p.customVal}</span></div>` : ''}
    ${newsHTML(p)}
  </div>`;
}
function renderSide(side) {
  const el = $(side + 'Cards');
  el.innerHTML = S[side].length ? S[side].map(p => cardHTML(side, p)).join('') :
    `<div class="empty">${side === 'give' ? 'Nothing on the table yet.<br>Search above to add who you\'re sending.' : 'Who are you getting back?<br>Search above to add them.'}</div>`;
}
document.addEventListener('click', e => {
  const x = e.target.closest('.pc-x'); if (x) removePlayer(x.dataset.side, x.dataset.name);
});
document.addEventListener('input', e => {
  if (!e.target.matches('.pc-slider input')) return;
  const p = S[e.target.dataset.side].find(q => q.name === e.target.dataset.name);
  if (!p) return;
  p.customVal = +e.target.value;
  e.target.nextElementSibling.textContent = p.customVal;
  e.target.closest('.pcard').querySelector('.pc-val .n').textContent = p.customVal;
  updateMeter();
});

/* ---------- meter ---------- */
function updateMeter() {
  const gA = adjTotal(S.give), tA = adjTotal(S.get);
  $('giveTot').textContent = gA.toFixed(0);
  $('getTot').textContent = tA.toFixed(0);
  $('mGiveRaw').textContent = rawTotal(S.give).toFixed(0);
  $('mGetRaw').textContent = rawTotal(S.get).toFixed(0);
  const net = tA - gA;
  $('mNet').textContent = (net > 0 ? '+' : '') + net.toFixed(1);
  $('mNet').style.color = net > 0 ? 'var(--green)' : net < 0 ? 'var(--red)' : 'var(--sand)';
  const all = [...S.give.map(p => [p, 'give']), ...S.get.map(p => [p, 'get'])].sort((a, b) => valueOf(b[0]) - valueOf(a[0]));
  const mb = $('mBest');
  mb.textContent = all.length ? `${all[0][0].name} (${all[0][1] === 'get' ? 'yours' : 'theirs'})` : '—';
  mb.style.color = all.length ? (all[0][1] === 'get' ? 'var(--green)' : 'var(--red)') : 'var(--sand)';
  const fill = $('meterFill'), mv = $('mathVerdict');
  if (!S.give.length || !S.get.length) { fill.style.width = '0'; mv.textContent = 'LOAD BOTH SIDES'; mv.style.color = 'var(--muted)'; return; }
  const pct = Math.max(-1, Math.min(1, net / Math.max(gA, tA, 1)));
  const w = Math.abs(pct) * 50;
  fill.style.width = w + '%';
  fill.style.left = pct >= 0 ? '50%' : (50 - w) + '%';
  fill.style.background = pct >= 0 ? 'linear-gradient(90deg, #4f6e2a, var(--green))' : 'linear-gradient(90deg, var(--red), #7a2418)';
  const pc = pct * 100;
  const [t, c] = pc > 25 ? ['HIGHWAY ROBBERY — YOU WIN', 'var(--green)'] : pc > 10 ? ['YOU WIN THIS ONE', 'var(--green)'] :
    pc >= -10 ? ['FAIR FIGHT', 'var(--amber)'] : pc >= -25 ? ["YOU'RE OVERPAYING", 'var(--red)'] : ['GETTING FLEECED', 'var(--red)'];
  mv.textContent = t; mv.style.color = c;
}

/* ---------- wire + board ---------- */
function renderWire() {
  const items = pool().filter(p => (p.trend !== 0 || p.status || p.hot) && ((p.note && p.note.length > 20) || p.liveNote || p.hot))
    .sort((a, b) => (b.liveNote ? 2 : 0) + (b.status ? 1 : 0) - ((a.liveNote ? 2 : 0) + (a.status ? 1 : 0)) || valueOf(b) - valueOf(a))
    .slice(0, 12);
  $('wire').innerHTML = items.length ? items.map(p => `<div class="w" style="border-top-color:${p.status ? 'var(--red)' : p.trend > 0 || p.hot ? 'var(--green)' : p.trend < 0 ? 'var(--amber)' : 'var(--rust)'}">
    <div class="wt"><span>${esc(p.name)}</span><span>${badges(p)}</span></div>
    <p>${esc([p.liveNote, p.note].filter(Boolean).join(' ') || (p.hot ? `Among the most-added players on Sleeper in the last 24 hours (${p.hot.count.toLocaleString()} adds).` : ''))}</p></div>`).join('')
    : `<div class="w"><p>Loading the wire…</p></div>`;
}
function renderBoard() {
  const poses = S.sport === 'NFL' ? ['ALL', 'QB', 'RB', 'WR', 'TE', 'DST'] : ['ALL', 'HEALTHY', 'INJURED'];
  $('posSeg').innerHTML = poses.map(p => `<button data-v="${p}" class="${S.bbPos === p ? 'on' : ''}">${p === 'DST' ? 'D/ST' : p}</button>`).join('');
  const head = S.sport === 'NFL'
    ? [['name', 'Player'], ['pos', 'Pos'], ['team', 'Team'], ['rank', 'ROS'], ['ppg', 'PPG'], ['val', 'Value'], ['', '']]
    : [['name', 'Player'], ['team', 'Team'], ['rank', 'ROS'], ['fpg', 'FP/G'], ['val', 'Value'], ['', '']];
  $('bbHead').innerHTML = head.map(([k, l]) => `<th data-k="${k}" class="${['team', 'ppg', 'fpg'].includes(k) ? 'hide-sm' : ''}">${l}${S.bbSort === k ? (S.bbDir < 0 ? ' ▼' : ' ▲') : ''}</th>`).join('');
  const q = norm($('bbSearch').value);
  let rows = pool().filter(p => {
    if (q && !norm(p.name).includes(q)) return false;
    if (S.sport === 'NFL' && S.bbPos !== 'ALL') return p.pos === S.bbPos;
    if (S.bbPos === 'HEALTHY') return !p.status;
    if (S.bbPos === 'INJURED') return !!p.status;
    return true;
  });
  const k = S.bbSort, d = S.bbDir;
  const get = p => k === 'val' ? valueOf(p) : k === 'rank' ? (p.rank ?? p.estRank ?? 900 + (p.sleeperRank || 99)) : k === 'ppg' ? (ppgOf(p)?.v ?? -1) : k === 'fpg' ? (parseFloat(p.stats?.FPG) || -1) : String(p[k] || '');
  rows.sort((a, b) => { const A = get(a), B = get(b); return (A > B ? 1 : A < B ? -1 : 0) * d; });
  const total = rows.length;
  rows = rows.slice(0, 250);
  const maxV = Math.max(1, ...pool().map(valueOf));
  const flag = p => `${p.status ? ` <span class="badge b-${p.status}">${p.status}</span>` : ''}${p.hot ? ' 🔥' : ''}${p.trend > 0 ? ' <span style="color:var(--green)">▲</span>' : p.trend < 0 ? ' <span style="color:var(--red)">▼</span>' : ''}`;
  $('bbBody').innerHTML = rows.map(p => {
    const v = valueOf(p), g = ppgOf(p);
    const cells = S.sport === 'NFL'
      ? `<td>${logoImg(p, 'tlogo-sm')}<b>${esc(p.name)}</b>${flag(p)}</td><td class="mono">${esc(p.pos === 'DST' ? 'D/ST' : p.pos)}</td><td class="mono hide-sm">${esc(p.teamLive || p.team)}</td><td class="mono">${p.rank ?? (p.est ? 'est' : 'NR')}</td><td class="mono hide-sm">${g ? g.v.toFixed(1) : '—'}</td>`
      : `<td>${logoImg(p, 'tlogo-sm')}<b>${esc(p.name)}</b>${flag(p)}</td><td class="mono hide-sm">${esc(p.teamLive || p.team)}</td><td class="mono">${p.rank ?? (p.est ? 'est' : 'NR')}</td><td class="mono hide-sm">${esc(p.stats?.FPG ?? '—')}</td>`;
    return `<tr>${cells}<td class="mono"><div class="vbar"><span style="width:${(v / maxV * 90).toFixed(0)}px"></span>${v.toFixed(0)}</div></td>
      <td style="white-space:nowrap"><button class="add g" data-a="give" data-n="${esc(p.name)}">+GIVE</button><button class="add r" data-a="get" data-n="${esc(p.name)}">+GET</button></td></tr>`;
  }).join('') + (total > 250 ? `<tr><td colspan="7" class="mono" style="color:var(--muted)">Showing 250 of ${total}. Use the filter to find anyone else.</td></tr>` : '');
}
$('posSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.bbPos = b.dataset.v; renderBoard(); });
$('bbHead').addEventListener('click', e => {
  const th = e.target.closest('th'); if (!th || !th.dataset.k) return;
  const k = th.dataset.k;
  if (S.bbSort === k) S.bbDir *= -1; else { S.bbSort = k; S.bbDir = ['name', 'rank', 'team', 'pos'].includes(k) ? 1 : -1; }
  renderBoard();
});
$('bbSearch').addEventListener('input', renderBoard);
$('bbBody').addEventListener('click', e => {
  const b = e.target.closest('.add'); if (!b) return;
  const p = pool().find(x => x.name === b.dataset.n); if (p) addPlayer(b.dataset.a, p);
});

function renderAll() {
  setSegOn('sportSeg', S.sport);
  const nfl = S.sport === 'NFL';
  $('fmtSeg').style.display = nfl ? '' : 'none';
  $('scoreSeg').style.display = nfl ? '' : 'none';
  $('fmtLabel').style.display = nfl ? '' : 'none';
  $('giveIn').placeholder = `Search ${nfl ? 'an NFL' : 'an NBA'} player to send away…`;
  $('getIn').placeholder = `Search ${nfl ? 'an NFL' : 'an NBA'} player to bring in…`;
  renderSide('give'); renderSide('get'); updateMeter(); renderWire(); renderBoard(); renderLive(); renderChips();
}
$('swapBtn').onclick = () => { [S.give, S.get] = [S.get, S.give]; hideReport(); renderAll(); };
$('clearBtn').onclick = () => { S.give = []; S.get = []; hideReport(); renderAll(); };

/* ---------- analysis ---------- */
function hideReport() { const r = $('report'); r.classList.remove('show'); r.innerHTML = ''; }
const LOAD_LINES = ['Pulling fresh headlines…', 'Reading the injury report…', 'Running the value math…', 'Checking the trend lines…', 'Pressure-testing the deal…', 'Writing the verdict…'];
const brief = p => ({ ...p, news: undefined, ppg: ppgOf(p)?.v ?? null, rankLabel: rankLabel(p) });

$('goBtn').onclick = async () => {
  const rep = $('report');
  if (!S.give.length || !S.get.length) { rep.classList.add('show'); rep.innerHTML = `<div class="err">Load at least one player on each side first.</div>`; return; }
  if (S.busy) return;
  S.busy = true; $('goBtn').disabled = true;
  rep.classList.add('show');
  let li = 0;
  rep.innerHTML = `<div class="loading"><div class="radar"></div><div style="flex:1"><div class="lt" id="loadT">${LOAD_LINES[0]}</div><div class="ls">Scanning news for every player in the deal…</div></div></div>`;
  const iv = setInterval(() => { li = (li + 1) % LOAD_LINES.length; const t = $('loadT'); if (t) t.textContent = LOAD_LINES[li]; }, 900);
  try {
    const r = await fetch('/api/analyze', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ sport: S.sport, settings: settings(), mode: $('mode').value, risk: $('risk').value, needs: $('needs').value, context: $('context').value, give: S.give.map(brief), get: S.get.map(brief) })
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Request failed');
    // Show the news the server used on the cards too.
    for (const p of [...S.give, ...S.get]) if (j.news && j.news[p.name]) { p.news = j.news[p.name]; newsCache.set(S.sport + ':' + p.name, Promise.resolve(p.news)); }
    renderSide('give'); renderSide('get');
    await new Promise(res => setTimeout(res, 600));
    renderDossier(j);
  } catch (e) {
    rep.innerHTML = `<div class="err">Couldn't reach the server (${esc(e.message)}). Is <code>npm start</code> still running?</div>`;
  } finally {
    clearInterval(iv); S.busy = false; $('goBtn').disabled = false;
  }
};

function verdictColor(v) {
  v = String(v || '').toUpperCase();
  if (v.includes('SMASH') || v === 'ACCEPT') return 'var(--green)';
  if (v.includes('LEAN ACCEPT')) return '#a8c45a';
  if (v.includes('COIN')) return 'var(--amber)';
  if (v.includes('LEAN DECLINE')) return '#e07a3a';
  return 'var(--red)';
}
const list = a => Array.isArray(a) && a.length ? `<ul>${a.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : `<div style="color:var(--muted)">—</div>`;
function renderDossier(r) {
  const col = verdictColor(r.verdict);
  const takes = (r.player_takes || []).map(t => {
    const o = ['BUY', 'SELL', 'HOLD'].includes(String(t.outlook).toUpperCase()) ? String(t.outlook).toUpperCase() : 'HOLD';
    return `<div class="take" style="border-left:4px solid ${t.side === 'get' ? 'var(--green)' : 'var(--red)'}">
      <div class="tn"><span>${esc(t.name)}</span><span class="badge o-${o}">${o}</span></div><p>${esc(t.take)}</p></div>`;
  }).join('');
  const engine = r.engine === 'claude-api' ? 'Claude API (your key)' : 'Bunker Brain (built-in engine)';
  $('report').innerHTML = `<div class="dossier">
    <div class="hazard" style="height:6px"></div>
    <div class="dossier-top">
      <div class="grade" style="color:${col}">${esc(r.grade || '?')}</div>
      <div>
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.18em;text-transform:uppercase">Verdict // you give ${S.give.map(p => esc(p.name)).join(', ')}</div>
        <div class="verdict-word" style="color:${col}">${esc(r.verdict || '—')}</div>
        <div class="headline">${esc(r.headline || '')}</div>
      </div>
      <div class="conf"><div class="n">${Number.isFinite(+r.confidence) ? Math.round(+r.confidence) : '—'}%</div><div class="s">confidence</div></div>
    </div>
    <div class="d-body">
      <p class="d-sum">${esc(r.summary || '')}</p>
      <div class="d-grid">
        <div class="d-col"><h4 style="color:var(--green)">▲ Why you do it</h4>${list(r.reasons_for)}</div>
        <div class="d-col"><h4 style="color:var(--red)">▼ Why you walk</h4>${list(r.reasons_against)}</div>
        <div class="d-col"><h4 style="color:var(--amber)">⚠ Watch list</h4>${list(r.risks)}</div>
      </div>
      <div class="takes">${takes}</div>
      ${r.counter_offer ? `<div class="counter"><h4>COUNTER-OFFER PLAY</h4><p>${esc(r.counter_offer)}</p></div>` : ''}
      <div class="d-foot">Engine: ${engine}. It weighed calculator value, injury status, trends, live headlines, your team mode, risk appetite and roster notes. Always check the final injury report before you accept.</div>
    </div>
  </div>`;
  $('report').scrollIntoView({ behavior: 'smooth', block: 'start' });
}


/* ---------- extra context box ---------- */
const CHIPS = {
  NFL: ['I already have the #1 defense', 'I really need roster spots', 'I need depth for bye weeks', "I'm stacked at WR", 'I already have an elite QB', 'Going all-in for the title'],
  NBA: ['I really need roster spots', "I'm loaded at guard", 'I need a center for rebounds and blocks', 'I need depth for injuries', 'Going all-in for the title', 'Rebuilding for next year']
};
function renderChips() {
  $('chips').innerHTML = CHIPS[S.sport].map(c => `<button class="chip" type="button">+ ${esc(c)}</button>`).join('');
}
$('chips').addEventListener('click', e => {
  const b = e.target.closest('.chip'); if (!b) return;
  const t = b.textContent.replace(/^\+\s*/, '');
  const box = $('context');
  const cur = box.value.trim();
  if (cur.toLowerCase().includes(t.toLowerCase())) return;
  box.value = cur ? cur.replace(/[.!]?$/, '. ') + t + '.' : t + '.';
  saveText();
});
function saveText() { try { localStorage.setItem('tb_needs', $('needs').value); localStorage.setItem('tb_context', $('context').value); } catch (e) {} }
try { $('needs').value = localStorage.getItem('tb_needs') || ''; $('context').value = localStorage.getItem('tb_context') || ''; } catch (e) {}
$('needs').addEventListener('input', saveText); $('context').addEventListener('input', saveText);

/* ---------- boot ---------- */
renderAll();
loadPool(S.sport).then(() => loadPool(S.sport === 'NFL' ? 'NBA' : 'NFL'));
